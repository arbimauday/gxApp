require('../../bootstrap')

import Vue from 'vue'
import App from './App.vue'

new Vue({
   el: '#app.vue',
   render: h => h(App)
});