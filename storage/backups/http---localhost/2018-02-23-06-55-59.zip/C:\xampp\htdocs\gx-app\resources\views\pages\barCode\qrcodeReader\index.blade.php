<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>QRCODEReader</title>
    <link rel="stylesheet" href="{{ asset('#') }}" />
</head>
<body>
<div id="app">
    <Plat></Plat>
</div>
<script src="{{ asset('barCodeWebCam/qrcodeReader.js') }}"></script>
</body>
</html>