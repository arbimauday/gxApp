<!-- START COPYRIGHT -->
<!-- START CONTAINER FLUID -->
<!-- START CONTAINER FLUID -->
  <div class="container-fluid  container-fixed-lg footer">
    <div class="copyright sm-text-center">
      <p class="small no-margin pull-left sm-pull-reset">
       <span class="hint-text">Copyright &copy; 2017 </span>
       <span class="font-montserrat">REVOX</span>.
       <span class="hint-text">All rights reserved. </span>
       <span class="sm-block"><a href="#" class="m-l-10 m-r-10">Terms of use</a> <span class="muted">|</span> <a href="#" class="m-l-10">Privacy Policy</a></span>
      </p>
      <p class="small no-margin pull-right sm-pull-reset">
        Hand-crafted <span class="hint-text">&amp; made with Love</span>
      </p>
      <div class="clearfix"></div>
    </div>
  </div>
<!-- END COPYRIGHT -->