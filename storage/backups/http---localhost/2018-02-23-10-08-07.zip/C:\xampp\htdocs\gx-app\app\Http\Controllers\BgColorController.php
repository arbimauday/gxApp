<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BgColorController extends Controller
{
    //
}
