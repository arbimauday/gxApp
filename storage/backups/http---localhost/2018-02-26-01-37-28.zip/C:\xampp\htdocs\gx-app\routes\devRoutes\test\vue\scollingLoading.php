<?php

Route::group([
    'prefix'    => config('devRoutes','test/vue')
],function (){
    Route::get('/scrolling','Test\Vue\Scrolling@index');
});