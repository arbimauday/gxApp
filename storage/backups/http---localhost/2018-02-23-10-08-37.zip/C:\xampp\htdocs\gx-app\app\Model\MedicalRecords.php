<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class MedicalRecords extends Model
{
    protected $table = '';
    protected $keyType = 'id';
    protected $guarded = ['id'];
}
