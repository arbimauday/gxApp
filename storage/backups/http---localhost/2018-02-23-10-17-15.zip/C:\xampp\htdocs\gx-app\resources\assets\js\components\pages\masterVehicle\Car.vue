<template>
    <div class="container full-width container-fluid container-fixed-lg">
        <div class="row">
            <div class="col-md-12 m-b-20">
                <router-link class="btn btn-primary" to="/addVehicle">Add New</router-link>
            </div>

            <div class="col-md-12">
                <div class="feed">
                    <div class="card social-card share col1 m-l-20" data-social="item">
                        <div class="circle" data-toggle="tooltip" title="Label" data-container="body"></div>
                        <div class="card-header clearfix">
                            <h5>DK 0000 AA</h5>
                            <h6>
                                <span class="location semi-bold"> Supra 125 </span>
                            </h6>
                        </div>
                        <div class="card-description">
                            <p class="hint-text">
                                <i class="pg-arrow_right p-r-5"></i>Divisi <span class="m-l-5">: Marketing</span>
                            </p>
                            <p class="hint-text">
                                <i class="pg-arrow_right p-r-5"></i>Color <span class="m-l-5">: Marketing</span>
                            </p>
                            <p class="hint-text">
                                <i class="pg-arrow_right p-r-5"></i>Fuel <span class="m-l-10">: Bensin</span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default{

    }
</script>