<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\MedicalRecords;

class MedicalRecordsController extends Controller
{
    //
}
