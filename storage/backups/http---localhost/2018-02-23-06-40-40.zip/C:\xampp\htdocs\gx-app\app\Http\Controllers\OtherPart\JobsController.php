<?php

namespace App\Http\Controllers\OtherPart;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class JobsController extends Controller
{
    //
}
